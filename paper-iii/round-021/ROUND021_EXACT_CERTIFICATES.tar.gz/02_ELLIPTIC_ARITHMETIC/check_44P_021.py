#!/usr/bin/env python3
import sys, hashlib
from fractions import Fraction
from math import gcd
from functools import reduce
sys.set_int_max_str_digits(0)
N=17;O=(0,1,-1);P=(64233,11741,1138)
def lcm(a,b):return abs(a*b)//gcd(a,b)
def norm(P):
 vals=[Fraction(x) for x in P];L=1
 for x in vals:L=lcm(L,x.denominator)
 a=[x.numerator*(L//x.denominator) for x in vals];g=reduce(gcd,[abs(x) for x in a if x]);a=[x//g for x in a]
 for x in a:
  if x:
   if x<0:a=[-v for v in a]
   break
 return tuple(a)
def F(P):
 a,z,w=P;n=N
 return 4*n*a**3-2*n*a*a*(w+z)+n*a*w*z-20*a*a*w-340*a*a*z+24*a*w*w+148*a*w*z+24*a*z*z-4*(z**3+w**3)
def grad(P):
 a,z,w=P;n=N
 return (12*n*a*a-4*n*a*(w+z)+n*w*z-40*a*w-680*a*z+24*w*w+148*w*z+24*z*z,-2*n*a*a+n*a*w-340*a*a+148*a*w+48*a*z-12*z*z,-2*n*a*a+n*a*z-20*a*a+48*a*w+148*a*z-12*w*w)
def hess(P):
 a,z,w=P;n=N
 return ((24*n*a-4*n*(w+z)-40*w-680*z,-4*n*a+n*w-680*a+148*w+48*z,-4*n*a+n*z-40*a+48*w+148*z),(-4*n*a+n*w-680*a+148*w+48*z,48*a-24*z,n*a+148*a),(-4*n*a+n*z-40*a+48*w+148*z,n*a+148*a,48*a-24*w))
def third(P,Q):
 P=norm(P);Q=norm(Q)
 if P!=Q:
  V=tuple(Q[i]-P[i] for i in range(3));G=grad(P);t=Fraction(sum(G[i]*V[i] for i in range(3)),F(V))
  return norm([Fraction(P[i])+t*V[i] for i in range(3)])
 G=grad(P);V=(G[1]*P[2]-G[2]*P[1],G[2]*P[0]-G[0]*P[2],G[0]*P[1]-G[1]*P[0]);H=hess(P);b=Fraction(sum(V[i]*H[i][j]*V[j] for i in range(3) for j in range(3)),2);t=-b/Fraction(F(V))
 return norm([Fraction(P[i])+t*V[i] for i in range(3)])
def add(P,Q):return third(third(P,Q),O)
Q=O
for _ in range(44):Q=add(Q,P)
A,z,w=Q;S=z**3+w**3;C=2*A-z;D=2*A-w
assert F(Q)==0 and A>5*z>w>0
assert A//gcd(A,S)==4
assert gcd(C,D)%83==0
assert hashlib.sha256((','.join(map(str,Q))).encode()).hexdigest()=='0b43a29be1c70fcd0c15f01ed6c453a3d5a26345b59d4e9dfc48eb1010c5a706'
print('PASS')
print('multiple=44P')
print('coordinate_digits=16232')
print('cubic_divisibility_defect=4')
print('boundary_collision_prime=83')
