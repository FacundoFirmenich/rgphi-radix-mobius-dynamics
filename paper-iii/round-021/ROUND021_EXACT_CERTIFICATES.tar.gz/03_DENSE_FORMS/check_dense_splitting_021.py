#!/usr/bin/env python3
import sympy as sp
from math import gcd
P,Q0,Q1,U,D,r=sp.symbols('P Q0 Q1 U D r', integer=True)
assert sp.expand((Q1-P)**2-(Q0-P)**2-(Q1-Q0)*(Q1+Q0-2*P))==0
assert sp.expand(U**2-P**2-(U-P)*(U+P))==0
assert sp.expand((D-U)**2-(Q1-U)**2-(D-Q1)*(D+Q1-2*U))==0
assert sp.expand(U**2-r**2*P**2-(U-r*P)*(U+r*P))==0
# Known countergraph tuple.
p,a,b,c=406,151,325,306
q0=p+a;q1=p+b;u=p+c;d=2*p+3*a
assert (q1-q0)*(q1+q0-2*p)%p==0
assert c*(2*p+c)%q1==0
assert (d-q1)*(d+q1-2*u)%u==0
assert (u-3*p)*(u+3*p)%d==0
assert gcd(q1-q0,q1+q0-2*p)==2
assert gcd(c,2*p+c)==2
assert gcd(d-q1,d+q1-2*u)==2
assert gcd(u-3*p,u+3*p)==2
assert (p,q0,q1,u,d)==(406,557,731,712,1265)
print('PASS')
print('four_factorizations=PASS')
print('known_countergraph_allocations=PASS')
print('odd_prime_power_overlap_bound=2')
