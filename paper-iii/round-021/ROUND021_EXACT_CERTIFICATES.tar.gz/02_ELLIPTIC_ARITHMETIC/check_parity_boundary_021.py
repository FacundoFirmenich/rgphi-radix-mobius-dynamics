#!/usr/bin/env python3
import sympy as sp
from math import gcd
A,z,w,n=sp.symbols('A z w n', integer=True)
S=z**3+w**3
F=4*n*A**3-2*n*A**2*(w+z)+n*A*w*z-20*A**2*w-340*A**2*z+24*A*w**2+148*A*w*z+24*A*z**2-4*S
H=4*n*A**2-2*n*A*(w+z)+n*w*z-20*A*w-340*A*z+24*w**2+148*w*z+24*z**2
assert sp.expand(F-(A*H-4*S))==0
assert sp.expand(F.subs({A:1,z:2,w:2}))==0
# Exact parity polynomial: for A=0,z=w=n=1 mod 2, H=1.
assert int(H.subs({A:0,z:1,w:1,n:1}))%2==1
# Boundary-point equivalence over a finite regression universe.
for p in [2,3,5,7,11,13,17,19,23,29,31]:
    for aa in range(p):
      for zz in range(p):
       for ww in range(p):
        if aa==zz==ww==0: continue
        lhs=((2*aa-zz)%p==0 and (2*aa-ww)%p==0)
        rhs=(aa%p!=0 and zz%p==(2*aa)%p and ww%p==(2*aa)%p)
        assert lhs==rhs
# Round-020 n=17 point.
P=(64233,11741,1138)
def Fn(P,n=17):
 a,b,c=P
 return 4*n*a**3-2*n*a*a*(c+b)+n*a*c*b-20*a*a*c-340*a*a*b+24*a*c*c+148*a*c*b+24*a*b*b-4*(b**3+c**3)
assert Fn(P)==0 and P[0]>5*P[1]>P[2]>0
assert P[0]%2==1 and (P[1]**3+P[2]**3)%P[0]==0
C=2*P[0]-P[1];D=2*P[0]-P[2]
assert gcd(C,D)==23
print('PASS')
print('F_equals_AH_minus_4S=PASS')
print('universal_boundary_point_R_1_2_2=PASS')
print('boundary_equivalence_regression=PASS')
print('n17_point_primitive_chamber=PASS')
print('n17_point_gcd_CD=23')
