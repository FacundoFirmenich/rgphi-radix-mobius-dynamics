# Clean-room build and verification

## Requirements

- Python 3.10 or later
- a C++17 compiler
- TeX Live with `amsart`, `tikz`, `cleveref`, `microtype`, `lmodern` and `bibtex8`

## One-command verification

```bash
make verify
```

This checks the canonical labelling across the article and all machine-readable artifacts, the 37-row nonsquare certificate, 1,001 bases of the exact CRT counterfamily, the projective content cocycle and the independent C++ edge checker.

## One-command compilation

```bash
make pdf
```

The article is compiled in the required order:

1. `pdflatex main.tex`
2. `bibtex8 main`
3. `pdflatex main.tex`
4. `pdflatex main.tex`

The supplement requires two `pdflatex` passes.

## Evidence boundary

The 1,001-base replay is a transcription regression, not the proof of infinitude. The infinite family follows from the exact generalized-CRT certificate in the article.
