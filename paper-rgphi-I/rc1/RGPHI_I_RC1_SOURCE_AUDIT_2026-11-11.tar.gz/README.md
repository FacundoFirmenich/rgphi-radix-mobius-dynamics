# RGΦ I — pre-submission RC1 · 2026-11-11

## External identity

**Primitive projective radix–Möbius dynamics: content cocycles and a sharp rigidity threshold**

This is the first mathematics paper intended for external publication from the RGΦ research programme. Internally it descends from “Paper III”; externally it is frozen as **RGΦ I**. The previous benchmark/Bellman manuscript remains a separate project and is not merged into this article.

## Main result

For the two-generator rational system

\[
T_B(x)=\{Bx\},\qquad S_B=\Phi\circ T_B\circ\Phi^{-1},\qquad \Phi(x)=\frac1{1+x},
\]

finite closed strongly connected components in the strict high domain \((1/2,1)\) are permutational under both generators through cardinality four. An explicit five-state component exists for an infinite arithmetic progression of integer bases and is nonpermutational. Hence the least nonpermutational cardinality is exactly five.

The article also introduces the primitive projective lift, the integer content cocycle, the cycle spectral identity, the high-cycle reduction budget, a finite-type theorem at fixed cardinality, and a universal CRT fibre theorem.

## Package

- `paper/main.pdf`: main research article (16 pages).
- `supplement/supplement.pdf`: certificates and reproducibility supplement (4 pages).
- `paper/main.tex`, `paper/references.bib`: source.
- `certificates/`: exact CSV/JSON certificates.
- `code/`: independent replay and regression checkers.
- `editorial/`: publication decision, journal strategy, cover letters and referee request.
- `metadata/`: claim ledger, publication state, arXiv metadata and checksums.

## Reproduce

```bash
make verify
make pdf
```

The full command sequence and requirements are recorded in `BUILD.md`.

## Authority boundary

The mathematical content has passed the internal RC1 adversarial audit. It is **not yet externally refereed, submitted, accepted, or archival-complete**. Before journal submission, the binding external gates are: specialist mathematical review, clean-room reproduction, final priority/literature chaining, and an immutable arXiv/Zenodo release.
